# MetaTrader 5 (MT5) Execution Integration

Digitech Algorithm can use **MetaTrader 5 as an execution venue** through a secure server-side bridge. The Android WebView must not store MT5 passwords, trading-account credentials, or terminal secrets.

## Architecture

`Digitech Algorithm Android app -> HTTPS execution API -> MT5 bridge/EA -> MetaTrader 5 terminal -> Broker`

The ICT engine produces a normalized order intent such as:

```json
{
  "symbol": "XAUUSD",
  "side": "BUY",
  "entry": 2910.50,
  "stop_loss": 2905.50,
  "take_profit": 2920.50,
  "risk_percent": 0.5,
  "strategy": "ICT_COMPLETE",
  "signal_id": "unique-idempotency-key"
}
```

The bridge should authenticate the request, validate symbol/volume/SL/TP, enforce daily-loss and max-position limits, submit the order to MT5, and return an execution/order identifier. It should also reconcile fills, rejects, partial fills, SL/TP changes and position state.

## MT5 side

A practical implementation is an **MQL5 Expert Advisor (EA)** attached to the MT5 terminal. The EA can poll a secure endpoint or receive approved commands through a controlled bridge and then use the MT5 trade API. Keep broker credentials inside MT5/the broker terminal environment, never in the Android APK.

## Safety

- Start with a demo MT5 account.
- Use HTTPS and strong authentication between the app and bridge.
- Use idempotency keys to prevent duplicate orders.
- Validate that the requested symbol exists and trading is allowed.
- Calculate volume from account equity, risk %, and SL distance.
- Reject orders that exceed daily loss, max open trades, or maximum spread/slippage limits.
- Maintain an emergency kill switch.
- Reconcile actual MT5 positions rather than assuming an order succeeded.

The Android app's MT5 option is an integration scaffold; a real MT5 bridge/EA and broker account are still required for live execution.
