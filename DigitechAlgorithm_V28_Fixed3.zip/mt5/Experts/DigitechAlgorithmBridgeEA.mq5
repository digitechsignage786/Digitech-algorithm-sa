//+------------------------------------------------------------------+
//| DigitechAlgorithmBridgeEA.mq5                                    |
//| Secure polling bridge for Digitech Algorithm ICT signals          |
//| DEFAULT: demo/safety mode. Test on a demo account first.          |
//+------------------------------------------------------------------+
#property strict
#include <Trade/Trade.mqh>
CTrade trade;

input string BridgeUrl = "https://YOUR-BRIDGE.example/api/mt5/next-order";
input string ApiToken = "CHANGE_ME";
input bool   AllowLiveOrders = false;
input double MaxRiskPercent = 0.5;
input int    MaxSpreadPoints = 80;
input int    PollSeconds = 2;
input long   MagicNumber = 26091301;

datetime lastPoll=0;
string lastSignalId="";

string JsonValue(string body,string key){
   string needle="\"" + key + "\"";
   int p=StringFind(body,needle);
   if(p<0) return "";
   p=StringFind(body,":",p);
   if(p<0) return "";
   p++;
   while(p<StringLen(body) && (StringGetCharacter(body,p)==' ' || StringGetCharacter(body,p)=='\"')) p++;
   int e=p;
   while(e<StringLen(body)){
      ushort c=StringGetCharacter(body,e);
      if(c==',' || c=='}' || c=='\"' || c=='\n' || c=='\r') break;
      e++;
   }
   return StringSubstr(body,p,e-p);
}
double JNum(string body,string key){ return StringToDouble(JsonValue(body,key)); }

int OnInit(){
   trade.SetExpertMagicNumber(MagicNumber);
   EventSetTimer(MathMax(1,PollSeconds));
   Print("Digitech MT5 Bridge EA started. AllowLiveOrders=",AllowLiveOrders);
   return(INIT_SUCCEEDED);
}
void OnDeinit(const int reason){ EventKillTimer(); }

void OnTimer(){
   if(!AllowLiveOrders) return; // hard safety default
   if(TimeCurrent()-lastPoll<PollSeconds) return;
   lastPoll=TimeCurrent();

   string headers="Content-Type: application/json\r\nAuthorization: Bearer "+ApiToken+"\r\n";
   char data[], result[];
   string result_headers;
   string payload="{\"terminal\":\""+IntegerToString(AccountInfoInteger(ACCOUNT_LOGIN))+"\"}";
   StringToCharArray(payload,data,0,WHOLE_ARRAY,CP_UTF8);

   ResetLastError();
   int code=WebRequest("POST",BridgeUrl,headers,5000,data,result,result_headers);
   if(code!=200){ Print("Bridge HTTP error: ",code," err=",GetLastError()); return; }

   string body=CharArrayToString(result);
   string id=JsonValue(body,"signal_id");
   if(id=="" || id==lastSignalId) return;

   string side=StringToUpper(JsonValue(body,"side"));
   string symbol=JsonValue(body,"symbol");
   double sl=JNum(body,"stop_loss"), tp=JNum(body,"take_profit");
   double risk=JNum(body,"risk_percent");
   if(risk<=0 || risk>MaxRiskPercent) risk=MaxRiskPercent;

   if(symbol=="" || sl<=0 || tp<=0 || (side!="BUY" && side!="SELL")){
      Print("Invalid order intent: ",body); return;
   }
   if(!SymbolSelect(symbol,true)){ Print("Symbol unavailable: ",symbol); return; }

   double ask=SymbolInfoDouble(symbol,SYMBOL_ASK), bid=SymbolInfoDouble(symbol,SYMBOL_BID);
   double point=SymbolInfoDouble(symbol,SYMBOL_POINT);
   if(point<=0) return;
   double spread=(ask-bid)/point;
   if(spread>MaxSpreadPoints){ Print("Spread guard rejected: ",spread); return; }

   // Conservative fixed-risk volume estimate.
   double equity=AccountInfoDouble(ACCOUNT_EQUITY);
   double moneyRisk=equity*risk/100.0;
   double px=(side=="BUY"?ask:bid);
   double tickSize=SymbolInfoDouble(symbol,SYMBOL_TRADE_TICK_SIZE);
   double tickValue=SymbolInfoDouble(symbol,SYMBOL_TRADE_TICK_VALUE);
   if(tickSize<=0 || tickValue<=0) return;
   double lossPerLot=MathAbs(px-sl)/tickSize*tickValue;
   if(lossPerLot<=0) return;
   double volume=moneyRisk/lossPerLot;

   double vmin=SymbolInfoDouble(symbol,SYMBOL_VOLUME_MIN);
   double vmax=SymbolInfoDouble(symbol,SYMBOL_VOLUME_MAX);
   double vstep=SymbolInfoDouble(symbol,SYMBOL_VOLUME_STEP);
   if(vstep<=0) vstep=vmin;
   volume=MathFloor(volume/vstep)*vstep;
   volume=MathMax(vmin,MathMin(vmax,volume));

   bool ok=false;
   if(side=="BUY") ok=trade.Buy(volume,symbol,0,sl,tp,"Digitech ICT "+id);
   else ok=trade.Sell(volume,symbol,0,sl,tp,"Digitech ICT "+id);

   if(ok){
      lastSignalId=id;
      Print("ORDER SENT ",side," ",symbol," vol=",volume," SL=",sl," TP=",tp," id=",id);
   }else{
      Print("ORDER REJECTED retcode=",trade.ResultRetcode()," ",trade.ResultRetcodeDescription());
   }
}
