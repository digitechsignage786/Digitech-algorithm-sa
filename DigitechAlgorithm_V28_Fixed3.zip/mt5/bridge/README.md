# Digitech Algorithm → MT5 Bridge (reference)

Architecture:
Android app -> HTTPS bridge -> MT5 EA -> broker.

This folder is a reference implementation outline. Do not expose the endpoint publicly without authentication, rate limits, TLS, audit logging and a persistent queue.

## Order intent
The app sends:
```json
{
  "signal_id":"unique-id",
  "symbol":"XAUUSD",
  "side":"BUY",
  "entry":2910.5,
  "stop_loss":2905.5,
  "take_profit":2920.5,
  "risk_percent":0.5,
  "strategy":"ICT_COMPLETE"
}
```

The bridge stores an approved intent and the EA polls `/api/mt5/next-order`. The EA has `AllowLiveOrders=false` by default; enable only after demo testing and independent risk review.

## MT5 WebRequest allow-list
In MT5: Tools → Options → Expert Advisors → enable WebRequest for the exact HTTPS bridge host.

Never put broker passwords in the Android app.
