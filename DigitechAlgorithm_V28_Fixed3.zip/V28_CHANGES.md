# Digitech Algorithm V28

- Forex live-feed priority upgrade.
- Twelve Data Forex/Commodities provider symbols auto-map from the selected app symbol.
- EUR/USD, GBP/USD, USD/JPY, USD/INR and XAU/USD mappings are built in.
- Twelve Data WebSocket heartbeat is sent every 10 seconds while connected.
- Historical candles preload before live ticks when a valid Twelve Data key is configured.
- No demo/fake candles.
- ICT Auto Drawing, BUY/SELL signals, Entry/SL/TP, MTF scan, backtesting and DA branding retained.
- Auto-rotate remains OFF by default; the app no longer turns sensor rotation on automatically.
