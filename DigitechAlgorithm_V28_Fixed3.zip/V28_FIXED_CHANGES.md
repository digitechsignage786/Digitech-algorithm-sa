# Digitech Algorithm V28 Fixed

- Fixed Android WebView local asset loading using AndroidX WebViewAssetLoader.
- Added stronger WebView settings for JavaScript, DOM storage, file/content access.
- Loads `index.html` through the Android app asset URL instead of `file:///android_asset`.
- Added AndroidX WebKit dependency.
- Kept Forex / Commodities / Crypto, ICT chart, live-feed architecture, backtest, MT5 bridge, DA branding and no-demo-feed behavior.
- Auto-rotate remains OFF by default.
