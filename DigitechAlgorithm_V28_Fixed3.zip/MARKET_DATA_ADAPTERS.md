# Digitech Algorithm — Market Data Adapters v22

## Supported adapter architecture

- **Binance public WebSocket**: BTCUSDT/ETHUSDT candle feed. Public market-data endpoints do not require API authentication.
- **OANDA FX/Gold relay**: EUR/USD and XAU/USD can be sourced from an authorized OANDA v20 account through a secure server-side relay. OANDA provides real-time rates and historical pricing through its API.
- **Custom authorized WebSocket**: for another licensed market-data provider.

## Normalized relay message

The app accepts a provider relay message in this form:

```json
{
  "type": "candle",
  "candle": {
    "time": "2026-09-13T09:20:00Z",
    "open": 100.0,
    "high": 101.0,
    "low": 99.5,
    "close": 100.8,
    "volume": 12345,
    "closed": true
  }
}
```

A tick can be normalized as:

```json
{"type":"tick","price":100.8}
```

## Security

Do not place broker API secrets inside the Android APK. Use a server-side relay with TLS, authentication, rate limits, symbol validation, and audit logging.

## Important

The ICT engine in this prototype remains a deterministic research approximation. Live feeds do not make its signals guaranteed or profitable. Validate with historical and paper trading before any real-money execution.
