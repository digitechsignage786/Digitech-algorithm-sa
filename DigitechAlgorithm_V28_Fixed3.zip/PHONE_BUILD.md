# Digitech Algorithm — Phone-only APK build

This project includes a GitHub Actions workflow that builds the APK in the cloud, so a PC is not required.

1. On an Android phone, create/sign in to a GitHub account.
2. Create a new repository.
3. Upload the contents of this project ZIP to the repository (including `.github/workflows/build-apk.yml`).
4. Open the repository's **Actions** tab and select **Build Digitech Algorithm APK**.
5. Tap **Run workflow** if it did not start automatically.
6. When the run finishes, open the workflow run and download the artifact named **DigitechAlgorithm-debug-apk**.
7. Extract it and install `app-debug.apk` on Android. Android may ask you to allow installation from that browser/file manager.

Important: this produces a debug APK. Live broker execution still requires the secure server-side execution architecture described in README.md.
