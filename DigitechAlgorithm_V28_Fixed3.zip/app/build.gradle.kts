plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.digitech.algorithm"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.digitech.algorithm"
        minSdk = 26
        targetSdk = 35
        versionCode = 8
        versionName = "1.4.1"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("com.google.firebase:firebase-auth:23.2.1")
    implementation("com.google.firebase:firebase-firestore:25.1.2")
    implementation("androidx.webkit:webkit:1.12.1")
}
