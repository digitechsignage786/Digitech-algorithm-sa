# Digitech Algorithm V18 — Real Cloud Backup Setup

V18 now contains real Firebase Authentication + Firestore cloud backup/restore code.

## Required one-time setup
1. Create a Firebase project at Firebase Console.
2. Enable Authentication → Sign-in method → Email/Password.
3. Create a Firestore Database.
4. Apply the rules in `firebase/firestore.rules`.
5. From Project settings → Your apps, create/register a Web app and copy its Firebase config.
6. Open `app/src/main/assets/firebase_config.json` and replace the `PASTE_...` values.
7. Build the APK with GitHub Actions.

The Firebase web API key is a project identifier and is not a password. Never put a service-account private key in the APK.

## What is stored
The app stores the backup JSON in Firestore at:
`users/{Firebase UID}/backups/main`

The user's Firebase password is never written to localStorage or the backup JSON.

## Important
This is real cloud sync after the user's own Firebase project is configured. The app cannot create/configure a Firebase project on the user's Google account automatically.
