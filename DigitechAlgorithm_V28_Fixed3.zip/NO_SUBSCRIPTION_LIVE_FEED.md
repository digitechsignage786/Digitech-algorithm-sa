# V25 No-Subscription Live Feed

Crypto uses Binance public WebSocket without subscription. Forex and commodities use only publicly accessible feeds when available; no fake/demo candles are generated. If no lawful public real-time source is reachable, the chart remains empty and shows LIVE DATA REQUIRED. Real ticks are aggregated into the selected timeframe and passed to the existing ICT engine.
