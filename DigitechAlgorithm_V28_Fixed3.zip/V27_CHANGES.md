# Digitech Algorithm V27

- TradingView-inspired responsive chart shell for desktop/tablet/landscape layouts.
- DA launcher icon and Digitech Algorithm app identity.
- App version 1.4.0 / versionCode 7.
- ICT Auto Drawing remains the primary chart feature.
- BUY/SELL, Entry/SL/TP, Backtesting and live-feed architecture retained.
- Auto-rotate setting defaults OFF; it can be enabled from Settings.
- No demo candles.
