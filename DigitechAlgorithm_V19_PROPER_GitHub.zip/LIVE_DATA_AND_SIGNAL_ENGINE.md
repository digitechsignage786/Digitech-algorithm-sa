# Live Market Data + ICT Signals

## Included
- Binance public WebSocket kline feed for BTCUSDT and ETHUSDT.
- Closed-candle buffering (up to 300 candles).
- Live price/status display.
- Deterministic ICT-style live signal prototype: liquidity sweep, displacement/MSS proxy, entry, SL, TP (2R), and research confidence.
- Custom `wss://` provider field for authorized market-data providers.

## Important limitations
The app does not scrape private TradingView chart data. For Forex, Gold, NSE/BSE, commodities and other venues, connect an authorized OHLC/WebSocket market-data provider and adapt its message schema in `startLiveFeed()`.

The live ICT engine is a research approximation, not a complete institutional ICT implementation and not a guarantee of profitable signals. Do not route signals to real-money execution until the feed, symbol mapping, session/timezone logic, corporate actions, spread/slippage, reconnect handling, and strategy validation are tested.
