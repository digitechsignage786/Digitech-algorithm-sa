# Digitech Algorithm — Android Prototype v0.2

Includes:
- TradingView live chart embed
- Crypto, Forex, Gold, NSE/BSE-oriented symbols and major indices
- Multi-timeframe selector
- ICT checklist dashboard: swings, liquidity, MSS/BOS/CHoCH, FVG/IFVG, OB/Breaker/Mitigation, Premium/Discount/OTE, sessions, AMD/PO3, risk
- `ICT_ENGINE_REFERENCE.pine` containing a programmable reference for swing structure, MSS and FVG logic.

Important:
The embedded TradingView chart is live, but a WebView cannot simply read TradingView's private chart data. Production-grade automatic signals require a permitted OHLC/market-data feed (and potentially TradingView/broker licensing) that is connected to the ICT engine. The current dashboard therefore does not claim live signals from the chart.

No trading algorithm can honestly guarantee 100% wins. Backtesting and paper trading are required before any live order execution.


## Real-money auto-trading
The app now includes a guarded Auto-Trade configuration UI. Direct broker credentials and order execution are intentionally not embedded in the Android WebView. For real-money execution, connect a secure server-side broker adapter over HTTPS, implement authentication, idempotent order submission, order-status reconciliation, position sizing, daily loss limits, max-open-trade limits, and an emergency kill switch. The UI does not claim that a broker connection is active until such a service is configured.


## MetaTrader 5 execution
The Auto-Trade panel now includes MetaTrader 5 (MT5 Bridge). Live MT5 execution uses a secure server-side bridge/MT5 Expert Advisor; MT5 credentials are never embedded in the Android APK. See `MT5_EXECUTION_BRIDGE.md`.


## MT5 execution package
The `mt5/Experts/DigitechAlgorithmBridgeEA.mq5` file provides a secure polling EA bridge. Live order execution is disabled by default (`AllowLiveOrders=false`). Configure the bridge URL in the EA and allow-list only that HTTPS host in MT5 WebRequest settings. Test on demo first.


## V19 upgrades
- Unified ICT engine: live signals and CSV backtesting call the same `ictEngineAt()` logic.
- Automatic chart overlays for STH/STL, ITH/ITL, LTH/LTL, BSL/SSL, EQH/EQL, BOS/MSS, FVG/IFVG, OB/Breaker/Mitigation, BPR, Premium/Discount/Equilibrium, OTE, session/kill-zone context, and Entry/SL/TP.
- Backtest target defaults to grade-based 3R/4R/5R when Target R:R is `0`; enter a positive number to override.
- Multi-market live feed architecture supports Binance public WS plus normalized WSS relays for authorized Forex, Gold, NSE/BSE, US, UK and index providers.
- Firebase cloud backup remains configuration-dependent: add your own Firebase project settings and enable Email/Password + Firestore.
- Real-time exchange data and news feeds may require provider subscriptions/licensing.
