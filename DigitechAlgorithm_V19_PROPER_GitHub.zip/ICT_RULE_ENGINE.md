# Digitech Algorithm — ICT Rule Engine v1

The production signal engine should process OHLCV candles, not screenshots.

## Pipeline
1. Normalize symbol/session/timezone.
2. Build HTF structure: LTH/LTL, ITH/ITL, STH/STL.
3. Mark external/internal liquidity: BSL, SSL, EQH/EQL, prior day/week/month highs/lows.
4. Detect sweep/raid and displacement.
5. Confirm MSS/BOS/CHoCH.
6. Detect FVG/IFVG, Order Block, Breaker, Mitigation and BPR.
7. Calculate dealing range, premium/discount and OTE.
8. Apply session/Kill Zone and AMD/PO3 filters.
9. Score confluence; reject incomplete setups.
10. Produce entry, invalidation/SL, TP and R:R.
11. Record every decision for backtesting and audit.

## Safety
No 100% win-rate claim. Live execution should remain disabled until the exact rules are backtested, paper-traded and connected to an approved broker/data feed.
