package com.digitech.algorithm

import android.annotation.SuppressLint
import android.app.Activity
import android.os.Bundle
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.ValueCallback
import android.content.Intent
import android.content.pm.ActivityInfo
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebResourceError
import android.webkit.WebResourceResponse
import androidx.webkit.WebViewAssetLoader
import androidx.webkit.WebViewClientCompat
import android.content.ActivityNotFoundException
import java.io.BufferedReader
import java.io.InputStreamReader
import com.google.firebase.FirebaseApp
import com.google.firebase.FirebaseOptions
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import org.json.JSONObject

class MainActivity : Activity() {
    private var filePathCallback: ValueCallback<Array<android.net.Uri>>? = null
    private var backupJson: String? = null
    private lateinit var webView: WebView
    private var firebaseReady = false

    inner class AppBridge {
        @JavascriptInterface fun setAutoRotate(enabled: Boolean) {
            runOnUiThread {
                requestedOrientation = if (enabled) ActivityInfo.SCREEN_ORIENTATION_SENSOR else ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
            }
        }

        @JavascriptInterface fun saveBackupEmail(email: String) {
            getPreferences(0).edit().putString("backup_email", email).apply()
        }

        @JavascriptInterface fun exportBackup(json: String) {
            backupJson = json
            val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "application/json"
                putExtra(Intent.EXTRA_TITLE, "DigitechAlgorithm_backup.json")
            }
            try { startActivityForResult(intent, 2001) } catch (_: ActivityNotFoundException) { }
        }

        @JavascriptInterface fun importBackup() {
            val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "application/json"
                putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("application/json", "text/plain"))
            }
            try { startActivityForResult(intent, 2002) } catch (_: ActivityNotFoundException) { }
        }

        @JavascriptInterface fun cloudStatus(): String = if (firebaseReady) "READY" else "NOT_CONFIGURED"

        @JavascriptInterface fun cloudSignUp(email: String, password: String, backupJson: String): String {
            if (!firebaseReady) return "NOT_CONFIGURED"
            return try {
                val auth = FirebaseAuth.getInstance()
                auth.createUserWithEmailAndPassword(email, password).addOnCompleteListener { task ->
                    if (task.isSuccessful) saveCloudBackup(backupJson)
                    val msg = if (task.isSuccessful) "SUCCESS" else "ERROR:" + (task.exception?.message ?: "signup failed")
                    webView.post { webView.evaluateJavascript("cloudAuthResult(" + JSONObject.quote(msg) + ")", null) }
                }
                "PENDING"
            } catch (e: Exception) { "ERROR:" + (e.message ?: "firebase error") }
        }

        @JavascriptInterface fun cloudLogin(email: String, password: String): String {
            if (!firebaseReady) return "NOT_CONFIGURED"
            return try {
                FirebaseAuth.getInstance().signInWithEmailAndPassword(email, password).addOnCompleteListener { task ->
                    val msg = if (task.isSuccessful) "SUCCESS" else "ERROR:" + (task.exception?.message ?: "login failed")
                    webView.post { webView.evaluateJavascript("cloudAuthResult(" + JSONObject.quote(msg) + ")", null) }
                }
                "PENDING"
            } catch (e: Exception) { "ERROR:" + (e.message ?: "firebase error") }
        }

        @JavascriptInterface fun cloudBackup(backupJson: String): String {
            if (!firebaseReady) return "NOT_CONFIGURED"
            if (FirebaseAuth.getInstance().currentUser == null) return "NOT_LOGGED_IN"
            return if (saveCloudBackup(backupJson)) "SUCCESS" else "ERROR"
        }

        @JavascriptInterface fun cloudRestore(): String {
            if (!firebaseReady) return "NOT_CONFIGURED"
            val user = FirebaseAuth.getInstance().currentUser ?: return "NOT_LOGGED_IN"
            FirebaseFirestore.getInstance().collection("users").document(user.uid).collection("backups").document("main").get()
                .addOnSuccessListener { doc ->
                    val data = doc.getString("json")
                    val msg = if (data != null) "DATA:" + JSONObject.quote(data) else "NO_DATA"
                    webView.post { webView.evaluateJavascript("cloudRestoreResult(" + JSONObject.quote(msg) + ")", null) }
                }
                .addOnFailureListener { e -> webView.post { webView.evaluateJavascript("cloudRestoreResult(" + JSONObject.quote("ERROR:" + (e.message ?: "restore failed")) + ")", null) } }
            return "PENDING"
        }

        @JavascriptInterface fun cloudLogout(): String {
            if (!firebaseReady) return "NOT_CONFIGURED"
            FirebaseAuth.getInstance().signOut()
            return "SUCCESS"
        }
    }

    private fun saveCloudBackup(json: String): Boolean {
        val user = FirebaseAuth.getInstance().currentUser ?: return false
        return try {
            FirebaseFirestore.getInstance().collection("users").document(user.uid).collection("backups").document("main")
                .set(mapOf("json" to json, "updatedAt" to System.currentTimeMillis()))
                .addOnSuccessListener { webView.post { webView.evaluateJavascript("cloudBackupResult('SUCCESS')", null) } }
                .addOnFailureListener { e -> webView.post { webView.evaluateJavascript("cloudBackupResult(" + JSONObject.quote("ERROR:" + (e.message ?: "backup failed")) + ")", null) } }
            true
        } catch (_: Exception) { false }
    }

    private fun initFirebaseFromAsset() {
        try {
            val text = assets.open("firebase_config.json").bufferedReader().use { it.readText() }
            val o = JSONObject(text)
            if (o.getString("apiKey").startsWith("PASTE_")) return
            val options = FirebaseOptions.Builder()
                .setApiKey(o.getString("apiKey"))
                .setApplicationId(o.getString("appId"))
                .setProjectId(o.getString("projectId"))
                .setStorageBucket(o.optString("storageBucket", null))
                .setGcmSenderId(o.optString("messagingSenderId", null))
                .build()
            if (FirebaseApp.getApps(this).isEmpty()) FirebaseApp.initializeApp(this, options)
            FirebaseApp.getInstance()
            firebaseReady = true
        } catch (_: Exception) { firebaseReady = false }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        initFirebaseFromAsset()
        val web = WebView(this)
        webView = web
        web.setBackgroundColor(android.graphics.Color.rgb(5, 11, 20))
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.databaseEnabled = true
        web.settings.allowFileAccess = true
        web.settings.allowContentAccess = true
        web.settings.javaScriptCanOpenWindowsAutomatically = true
        web.settings.cacheMode = WebSettings.LOAD_DEFAULT
        val assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()
        web.webViewClient = object : WebViewClientCompat() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                return assetLoader.shouldInterceptRequest(request.url)
            }
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                return false
            }
            override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) {
                super.onReceivedError(view, request, error)
            }
        }
        web.addJavascriptInterface(AppBridge(), "AndroidBridge")
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(webView: WebView, filePath: ValueCallback<Array<android.net.Uri>>, fileChooserParams: FileChooserParams): Boolean {
                filePathCallback?.onReceiveValue(null)
                filePathCallback = filePath
                return try { startActivityForResult(fileChooserParams.createIntent(), 1001); true } catch (_: Exception) { filePathCallback = null; false }
            }
        }
        web.loadUrl("https://appassets.androidplatform.net/assets/index.html")
        setContentView(web)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 1001) {
            val result = if (resultCode == RESULT_OK && data?.data != null) arrayOf(data.data!!) else null
            filePathCallback?.onReceiveValue(result); filePathCallback = null
        } else if (requestCode == 2001 && resultCode == RESULT_OK && data?.data != null) {
            try { contentResolver.openOutputStream(data.data!!)?.use { it.write((backupJson ?: "{}").toByteArray()) }; android.widget.Toast.makeText(this, "Backup saved", android.widget.Toast.LENGTH_SHORT).show() } catch (_: Exception) { android.widget.Toast.makeText(this, "Backup save failed", android.widget.Toast.LENGTH_SHORT).show() }
            backupJson = null
        } else if (requestCode == 2002 && resultCode == RESULT_OK && data?.data != null) {
            try {
                val text = contentResolver.openInputStream(data.data!!)?.use { BufferedReader(InputStreamReader(it)).readText() } ?: ""
                val escaped = JSONObject.quote(text)
                webView.post { webView.evaluateJavascript("applyBackupText(" + escaped + ")", null) }
            } catch (_: Exception) { }
        }
    }
}
